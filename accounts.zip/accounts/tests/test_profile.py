import pytest
from django.urls import reverse

@pytest.mark.django_db
def test_get_profile(api_client, create_user):

    user = create_user()

    api_client.force_authenticate(user=user)

    url = reverse("profile")

    response = api_client.get(url)

    assert response.status_code == 200
    assert response.data["email"] == user.email